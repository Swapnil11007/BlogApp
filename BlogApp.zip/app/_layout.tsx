import Index from "./Index";

export default function RootLayout() {
  return <Index/>
}
